package com.example.MatchingTune.Controller;

import com.example.MatchingTune.Service.MusicService;

public class MusicControllerImpl extends UserController {
    public MusicControllerImpl(MusicService musicService) {
        super(musicService);
    }
}
