package com.example.MatchingTune;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MatchingTuneApplication {
	public static void main(String[] args) {
		SpringApplication.run(MatchingTuneApplication.class, args);
	}
}