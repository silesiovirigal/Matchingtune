package com.example.MatchingTune.Controller;

import com.example.MatchingTune.Service.MusicService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/music")
public class UserController {

    private final MusicService musicService;

    // Construtor para injeção de dependência
    public UserController(MusicService musicService) {
        this.musicService = musicService;
    }

    @GetMapping("/recommendations")
    public ResponseEntity<String> getMusicBuddyRecommendations(@RequestParam String preferences) {
        String result = musicService.getMusicBuddyRecommendations(preferences);
        if (result != null && !result.isEmpty()) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/similar")
    public ResponseEntity<String> getTasteDiveSimilar(@RequestParam String query) {
        String result = musicService.getTasteDiveSimilar(query);
        return result != null && !result.isEmpty() ? ResponseEntity.ok(result) : ResponseEntity.notFound().build();
    }

    @GetMapping("/geolocated")
    public ResponseEntity<String> getGeolocatedInfo(@RequestParam String location) {
        String result = musicService.getGeolocatedInfo(location);
        return result != null && !result.isEmpty() ? ResponseEntity.ok(result) : ResponseEntity.notFound().build();
    }

    @GetMapping("/youtube")
    public ResponseEntity<String> getYoutubeMusicInfo(@RequestParam String query) {
        String result = musicService.getYoutubeMusicInfo(query);
        return result != null && !result.isEmpty() ? ResponseEntity.ok(result) : ResponseEntity.notFound().build();
    }

    @GetMapping("/soundcloud")
    public ResponseEntity<String> getSoundCloudMusic(@RequestParam String query) {
        String result = musicService.getSoundCloudMusic(query);
        return result != null && !result.isEmpty() ? ResponseEntity.ok(result) : ResponseEntity.notFound().build();
    }
}
