package com.example.MatchingTune.Service;

import org.springframework.stereotype.Service;

@Service
public class MusicService {

    private MusicService() {
    }

     public static MusicService createMusicService() {
        return new MusicService();
    }

    public String getMusicBuddyRecommendations(String preferences) {
        // Simulação de lógica
        return "Recomendações para: " + preferences;
    }

    public String getTasteDiveSimilar(String query) {
        return "Músicas semelhantes para: " + query;
    }

    public String getGeolocatedInfo(String location) {
        return "Informações de música para a localização: " + location;
    }

    public String getYoutubeMusicInfo(String query) {
        return "Informações do YouTube para: " + query;
    }

    public String getSoundCloudMusic(String query) {
        return "Músicas do SoundCloud para: " + query;
    }
}