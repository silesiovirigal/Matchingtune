package com.example.MatchingTune;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MatchingTuneApplicationTests {

	@Test
	void contextLoads() {
	}

}
